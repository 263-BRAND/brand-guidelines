---
name: 263-vi
description: 263 品牌 VI 规范 — 提供品牌色板、字体、Logo 和公司数据。任何涉及 263 品牌输出的场景（PPT、网页、文档等）都应使用此 skill。
---

# 263 品牌 VI 规范

## 你的职责

当用户需要输出涉及 263 品牌的内容时，你负责品牌数据层的全部决策：

1. 判断生成模式（Template 还是 Themed）— 从用户自然语言推断
2. 确定品牌上下文（配色方案 + Logo 归属）
3. 从 `brand-tokens.json` 和 `company-data.json` 读取品牌数据
4. 在输出开头透明声明当前模式

## 品牌数据文件

| 文件 | 内容 | 何时读取 |
|------|------|----------|
| `brand-tokens.json` | 色板、字体层级、Logo、硬规则 | 任何视觉输出 |
| `company-data.json` | 公司信息、产品、里程碑、资质 | 需要公司/产品信息时 |
| `design-skill-recommendations.json` | 平台设计 skill 推荐 | 无设计 skill 时 |
| `CONTEXT.md` | 领域模型（术语定义、产品详情） | 不确定术语含义时 |

## 生成模式判断

从用户自然语言推断 Template 还是 Themed，**不穷举关键词，按特征推理**：

| 维度 | Template（母版型） | Themed（主题型） |
|------|-------------------|------------------|
| 受众 | 组织内部 | 组织外部 |
| 目的 | 汇报/同步/述职 | 说服/展示/介绍 |
| 设计 | 统一规范，不追求个性 | 品牌约束内允许个性发挥 |

判断时问自己三个问题：
1. 受众是谁？（内部 → Template，外部 → Themed）
2. 目的是什么？（汇报 → Template，说服 → Themed）
3. 有母版要求吗？（有 → Template）

二选一，不要犹豫。即使用户说"帮我做个PPT"没有额外信息，也选最可能的并声明。

## 输出透明声明

每次生成视觉内容时，**开头第一句**必须声明模式：

- Template 判断时：`"我将按**内部汇报**的设计方式制作（统一母版）。如果你是用于对外展示，请告诉我，我会切换设计风格。"`
- Themed 判断时：`"我将按**对外展示**的设计方式制作（品牌主题 + 个性化设计）。如果你是用于内部工作汇报，请告诉我具体场景，我会切换为统一母版。"`

目的：用户不需要预先知道有两个模式。看到声明即可纠正。

## 生成前确认

在判断完模式和上下文后，**用对话框让用户逐个确认以下选项**，不要跳过。用户确认后再开始生成：

1. **展示场景：** 内部汇报（统一母版）还是对外展示（个性化设计）？
2. **配色方案：** 集团红还是商务蓝？（默认：集团红。配色决定 Logo 归属——集团红用集团 Logo，商务蓝用云通信 Logo）
3. **设计 Skill：** 是否需要手动调用其他设计类 skill？（如 `frontend-design`。选择"否"则使用内置兜底渲染器）

用户回复后，按确认结果校准模式与品牌上下文，然后进入工作流。

## 工作流

### 前置步骤（四条路径共用）

1. **判断模式** → Template 还是 Themed（见上方判断逻辑）
2. **确定品牌上下文** → 配色方案（默认集团红）+ Logo 归属（默认集团 Logo，按业务线切换）
3. **输出透明声明** → 告知用户当前模式和切换方式
4. **读取品牌数据** → `brand-tokens.json`（必须）+ `company-data.json`（按需）

### 路径选择

| | 路径 A（从零生成） | 路径 B（改写已有） |
|---|---|---|
| **Template** | 按母版填空 | 对齐母版规范 |
| **Themed** | 品牌数据 + 设计 skill 创作 | 品牌约束内重新设计 |

### 路径 A × Template：从零按母版生成

用户描述需求，没有现成文件 → 你按固定母版从零生成

1. 根据用户需求策划大纲和页面结构
2. 每页按母版填空（封面页固定布局、内容页标准版式）
3. **全部硬规则锁死**：字号、颜色、Logo 位置均不可变
4. 设计 skill **不介入**
5. 无设计 skill 时：用 `node generate.js <pages.json>` 兜底渲染

### 母版封面页（Template Cover）

封面页采用统一固定设计，不走 Themed 路径：

| 属性 | 值 | 刚性 |
|------|-----|:--:|
| 背景 | `#F2F2F2`（品牌 lightGray） | MUST |
| Logo 呈现 | ASCII 字符画（monospace），红色品牌主色，页面水平居中，距顶约 9% | MUST |
| 标题 | 微软雅黑 Bold，64pt，深色品牌 dark，水平居中 | MUST |
| 汇报人/部门 | 微软雅黑，26pt，品牌 gray，水平居中，红色圆点分隔 | MUST |
| 公司全称 | 底部居中，22pt，品牌 gray + opacity 0.45 | MUST |
| 整体布局 | 纯色背景，无纹理，无边框，上下预留安全区 | MUST |

**ASCII Logo 数据：** 从集团红心 Logo 提取，固定 36 行 monospace 字符，比例已校准（字符正方形 + 等距采样）。HTML 渲染时使用 `font-family: Courier New, monospace; line-height: 0.6; font-size: 11pt`。数据硬编码于渲染器 `renderer/slides/cover.js`。

**封面无右上角/左上角独立 Logo。** ASCII 图案即是封面的品牌标识，不额外放置 PNG Logo。此规则仅适用于 Template 封面，内页和结尾页的 Logo 规则不变。

**使用时**：在 `pages.json` 中设置 `"scene": "template"`，渲染器自动切换到 ASCII 封面。不设置或设置为其他值时使用 Themed 封面（红底渐变 + 左上角 Logo）。

### 路径 A × Themed：从零创作型生成

用户描述需求，没有现成文件，需要对外展示效果 → 你策划内容 + 设计 skill 排版

1. 根据用户需求策划大纲、页面结构、配图/图表方案
2. 将品牌数据（色板、字体层级、Logo 规则）交给设计 skill
3. **硬规则锁死，软规则由设计 skill 自由发挥**
4. 品牌数据层（你管）：色彩不准偏、字体不准换、Logo 不准动、结尾页格式固定
5. 表现层（设计 skill 管）：排版布局、装饰元素、图表风格、动画效果、阴影层次

### 路径 B × Template：已有文件对齐母版

用户提供已有 HTML/JSON 文件，需要对齐内部汇报母版

1. 读取已有文件，提取页面结构和内容
2. **替换所有颜色为品牌色板色值**（不只是主色，包括所有辅助色：绿→主色/辅色，蓝→深色/辅色，灰→品牌灰）。Template 路径下原文件的一切非品牌颜色必须全部清除
3. 替换字体为微软雅黑，修正字号到 Template 标准
4. 嵌入 Logo（内页右上角（画布宽度 4.2%，见 `layout.innerPageLogo.size`），符合深浅底规则）
5. **检查 Logo 安全区**：右上角（画布宽度 4.2%，见 `layout.innerPageLogo.size`） 范围不得有任何 UI 组件（翻页提示、页码、进度条等）。如有冲突，移动 UI 组件而非移动 Logo
6. 对齐母版布局（封面、目录、内容、结尾页统一版式）
7. **结尾页强制替换**：原文件的结尾/感谢页内容全部丢弃，替换为 VI 标准结尾（居中 Logo + slogan PNG）。此规则不可协商，Themed 模式下同样适用
8. VI skill 全控，设计 skill 不介入

### 路径 B × Themed：已有文件品牌重设计

用户提供已有文件，需要对外展示级别重新设计

1. 读取已有文件，提取内容信息
2. 将内容和品牌数据（色板、字体层级、Logo 规则）交给设计 skill
3. 设计 skill 在硬规则约束内重新设计排版和视觉
4. 品牌数据层锁死，表现层自由发挥（同路径 A × Themed 的边界）

## 品牌规则

### 色彩

两套配色方案，通过 `brand-tokens.json` → `colorSchemes` 选择：

- **集团红（group-red）**：主色 `#D0121B`，集团层面默认
- **商务蓝（business-blue）**：主色 `#1677FF`，待官方确认后启用

每个方案 9 个色值。所有颜色从 JSON 读取，不硬编码。

### 字体

**正文字体：微软雅黑。** 字号值在不同输出格式下取不同数据源，数值即 pt（PPTX/PDF/印刷原生单位），不硬编码：

| 层级 | HTML `typography.html` | PPTX `typography.pptx` | 刚性 |
|------|------------------------|------------------------|------|
| 封面标题 | 64 | 64 | Template MUST / Themed 区间 |
| 内容页标题 | 40 | 24 | 同上 |
| 副标题 | 30 | 20 | 同上 |
| 正文 | 26 | 18 | MUST |
| 图表标签/注脚 | 22 | 14 | MUST |

**Template：全部使用固定值。Themed：设计 skill 在区间内自由决定。** 数据源：`brand-tokens.json` → `typography.html.scale` / `typography.pptx.scale`。

**跨格式直出规则：** HTML/CSS 输出在数字后加 `pt` 后缀（如 `font-size: 64pt`），PPTX 直接写入数字（PPTX fontSize 原生单位即 pt）。**禁止任何 pt↔px 乘除换算。** 值从 JSON 读取为 number，单位由输出端明确补上。

### Logo

| 规则 | 刚性 |
|------|:--:|
| 内页 Logo 尺寸：画布宽度的 4.2%（`layout.innerPageLogo.size`） | MUST |
| Logo 安全区内禁止任何装饰元素、文字、页码、页脚组件 | MUST |
| 浅色底 → 彩稿 Logo / 深色底 → 反白 Logo | MUST |
| 结尾页：原内容全部丢弃，替换为居中 Logo + slogan PNG 图片（不可用文字代替） | MUST |
| 封面 Logo（Themed）：左上角，画布宽度 6.5%（`layout.coverLogo`），安全区同内页规则 | MUST |
| 封面 Logo（Template）：不使用 PNG Logo，以 ASCII 字符画替代（见"母版封面页"章节） | MUST |

**Logo 安全区 = Logo 图片的矩形边界框。** 安全区外边界即 Logo 边缘，不需要额外 margin。坐标从 `brand-tokens.json` → `layout` 读取。

**绝对禁止：** 任何内容元素（标题、正文、页码、页脚、装饰、分割线、图标、背景图形）的任何像素进入安全区。Template 和 Themed 模式下同等适用，无一例外。

**内页安全区（`layout.innerPageLogo`）：**
- Logo 位于右上角，`right` / `top` 定位，`size` 正方形
- 内容区最大右边界 = 画布宽度 − right − size = 画布宽度 × 91.6%（以默认值 right:4.2%, size:4.2% 计）
- 页脚右侧元素（页码等）必须显式约束在此边界内，禁用 `space-between` 布局

**封面安全区（`layout.coverLogo`）：**
- Logo 位于左上角，`left` / `top` 定位，`size` 正方形
- 封面 Logo 尺寸（6.5%）大于内页（4.2%），视觉权重更高
- 安全区范围：X: left ~ left+size, Y: top ~ top+size
- 封面常见违规：装饰圆/半透明图形侵入左上角、标题文字 `padding-left` 不足导致进入安全区
- **生成封面时强制检查：** 所有装饰元素（背景圆、渐变块、几何图形）的左上边界必须 ≥ left+size，标题文字的 `left` 或 `padding-left` 必须 ≥ left+size

### 品牌上下文（Logo 按业务线切换）

默认使用集团 Logo。当用户指定业务线（如云通信）时，切换到该业务线的 Logo，其他品牌规则不变。

从 `brand-tokens.json` → `logos.businessLines` 查 Logo 路径。

### 硬规则

Template：全部锁死。Themed：以下 MUST 规则不可违反，其余交设计 skill。

从 `brand-tokens.json` → `hardRules` 读取完整清单。

### 结尾页比例

居中 Logo + slogan PNG。尺寸按画布比例计算，不硬编码：

- **Logo：** 高度 = 画布高度 × 30%~36%，宽度自适应（`object-fit: contain`），不强行设固定宽高
- **Slogan：** 宽度 = 画布宽度 × 45%~55%，高度按原图比例自适应，不自行猜测宽高比
- **间距：** Logo 与 slogan 之间留白 = 画布高度 × 6%~8%

以 1280×720 画布为例：Logo 约 220–260px 高，slogan 约 580–700px 宽，间距约 45–55px。

## 与设计 skill 协作

VI skill 是品牌数据层，设计 skill 是表现层。

| 层 | 谁负责 | 锁定的内容 |
|----|--------|-----------|
| 品牌数据层 | VI skill | 色彩、字体、Logo 规则、结尾页格式、硬规则 |
| 表现层 | 设计 skill | 排版布局、装饰元素、图表风格、动画、阴影 |

**Brand Data Contract：** VI skill 输出给设计 skill 的数据结构：

```json
{
  "colorScheme": "group-red",
  "colors": { "primary": "#D0121B", "primaryLight": "#FE343F", "primaryDark": "#AC000A", "accent": "#FF777F", "dark": "#2D3847", "gray": "#595959", "lightGray": "#F2F2F2", "white": "#FFFFFF", "black": "#000000" },
  "typography": { "fontFamily": "微软雅黑", "html": { "body": 26 }, "pptx": { "body": 18 } },
  "logo": { "innerPage": { "size": "4.2% of canvas width, square" }, "safeZone": "Logo bounding box, zero tolerance" },
  "hardRules": ["Logo安全区", "结尾页格式", "主色不可偏色"],
  "mode": "themed"
}
```

设计 skill 消费这个结构，在硬规则约束内自由创作。

## 输入格式

VI skill 不负责解析文件。外部 Agent 自行调用 MCP 或其他工具摘取内容后送入管线。

| 分级 | 格式 | 可靠性 |
|------|------|--------|
| 原生支持 | HTML、JSON | 路径 B 完整能力 |
| 尽力而为 | .pptx、.docx、.pdf、图片 | Agent 尽力提取 + VI 化，不保证完美 |

如果用户提供的文件格式不在原生支持列表中，告知用户："这个文件格式需要先提取内容。我会尽力处理，但可能需要你确认提取结果是否准确。"

## HTML 输出规范（无设计 skill 时）

当使用兜底渲染器时，按以下规范输出：
- 零外部依赖，单一 HTML 文件，浏览器直接打开
- 播放壳：全屏/键盘翻页/点击翻页
- 内页 Logo 固定右上角（画布宽度 4.2%，见 `layout.innerPageLogo.size`）
- 深底自动反白
- 字号不低于 20pt

## 禁止事项

- 禁止使用非色板颜色（不自己发明颜色）
- 禁止在 Template 路径下保留原文件的非品牌颜色（绿色/蓝色/橙色等必须全部替换为品牌色板值）
- 禁止保留原文件的结尾页内容（必须替换为 VI 标准：居中 Logo + slogan PNG）
- 禁止任何像素进入 Logo 安全区——安全区 = Logo 矩形边界框，无一例外。页脚页码用固定右边界，不得越界
- 禁止编造公司信息（名称、股票代码、产品、数据等）
- 禁止 font-size < 各格式底线（HTML 正文 ≥ 24pt 极限 ≥ 20pt；PPTX 正文 ≥ 16pt 极限 ≥ 12pt）
- 禁止在内页自定义 Logo 位置（右上角（画布宽度 4.2%，见 `layout.innerPageLogo.size`） 固定）
- 禁止在 Logo 安全区放置任何装饰元素
- 禁止在 Template 路径下自行调整字号、布局、配色
- 禁止跳过透明声明（每次生成必须告知用户当前模式）

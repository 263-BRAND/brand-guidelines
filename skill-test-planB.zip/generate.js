// generate.js — 263 PPT Renderer
// Usage: node generate.js <pages.json>
// Output: <pages>.html (self-contained, zero-dependency slideshow)

const fs = require('fs');
const path = require('path');

const pagesPath = process.argv[2];
if (!pagesPath) {
  console.error('Usage: node generate.js <pages.json>');
  process.exit(1);
}
if (!fs.existsSync(pagesPath)) {
  console.error('File not found: ' + pagesPath);
  process.exit(1);
}

const tokens = JSON.parse(fs.readFileSync('brand-tokens.json', 'utf-8'));
const pages = JSON.parse(fs.readFileSync(pagesPath, 'utf-8'));

// Validate colorScheme
if (!pages.colorScheme || !tokens.colorSchemes[pages.colorScheme]) {
  console.error('Invalid colorScheme: ' + pages.colorScheme + '. Must be one of: ' + Object.keys(tokens.colorSchemes).join(', '));
  process.exit(1);
}
if (!pages.slides || !Array.isArray(pages.slides) || pages.slides.length === 0) {
  console.error('pages.json must contain a non-empty "slides" array.');
  process.exit(1);
}

// Resolve background templates with color scheme values
var c = tokens.colorSchemes[pages.colorScheme];
function resolveBg(bgTemplate) {
  var result = bgTemplate;
  var keys = Object.keys(c);
  for (var i = 0; i < keys.length; i++) {
    result = result.replace(new RegExp('\\{' + keys[i] + '\\}', 'g'), c[keys[i]]);
  }
  return result;
}

// Resolve all background presets
var resolvedBg = { cover: {}, inner: {} };
var bgPresets = tokens.backgrounds;
var coverKeys = Object.keys(bgPresets.cover);
for (var i = 0; i < coverKeys.length; i++) {
  resolvedBg.cover[coverKeys[i]] = resolveBg(bgPresets.cover[coverKeys[i]]);
}
var innerKeys = Object.keys(bgPresets.inner);
for (var j = 0; j < innerKeys.length; j++) {
  resolvedBg.inner[innerKeys[j]] = resolveBg(bgPresets.inner[innerKeys[j]]);
}

// Validate slide backgrounds
var innerBgKeys = Object.keys(resolvedBg.inner);
for (var k = 0; k < pages.slides.length; k++) {
  var slide = pages.slides[k];
  var t = slide.type;
  if (t === 'cover') {
    if (slide.background && !resolvedBg.cover[slide.background]) {
      console.error('Slide ' + k + ' (' + t + '): invalid background "' + slide.background + '". Must be one of: ' + Object.keys(resolvedBg.cover).join(', '));
      process.exit(1);
    }
  } else if (slide.background && !resolvedBg.inner[slide.background]) {
    console.error('Slide ' + k + ' (' + t + '): invalid background "' + slide.background + '". Inner slides must use: ' + innerBgKeys.join(', '));
    process.exit(1);
  }
}

// Load slide renderers
const slideTypes = ['cover', 'section', 'content', 'cards', 'timeline', 'end'];
const renderers = {};
for (const t of slideTypes) {
  renderers[t] = require('./renderer/slides/' + t + '.js');
}

// Render each slide
const slideHtmlArray = [];
for (let i = 0; i < pages.slides.length; i++) {
  const slide = pages.slides[i];
  if (!slide.type || !slideTypes.includes(slide.type)) {
    console.error('Slide ' + i + ': unknown or missing type "' + (slide.type || '') + '". Must be one of: ' + slideTypes.join(', '));
    process.exit(1);
  }
  const renderFn = renderers[slide.type];
  const html = renderFn(slide, tokens, pages, i, resolvedBg);
  slideHtmlArray.push(html);
}

// Embed logos as base64
function logoBase64(logoPath) {
  if (!fs.existsSync(logoPath)) {
    console.warn('Warning: logo not found: ' + logoPath);
    return '';
  }
  const ext = path.extname(logoPath).toLowerCase();
  const mime = ext === '.svg' ? 'image/svg+xml' : 'image/png';
  const data = fs.readFileSync(logoPath).toString('base64');
  return 'data:' + mime + ';base64,' + data;
}

const logoSet = pages.logoSet || 'group';
const logos = tokens.logos[logoSet] || tokens.logos.group;
const logoColorB64 = logoBase64(logos.color);
const logoWhiteB64 = logos.white ? logoBase64(logos.white) : '';
const sloganB64 = tokens.slogan ? logoBase64(tokens.slogan) : '';

// Build output
const html = buildHtml({
  slides: slideHtmlArray.join('\n'),
  tokens: tokens,
  colorScheme: pages.colorScheme,
  logoColorB64: logoColorB64,
  logoWhiteB64: logoWhiteB64,
  sloganB64: sloganB64,
  totalSlides: pages.slides.length
});

const outPath = pagesPath.replace(/\.json$/, '.html');
fs.writeFileSync(outPath, html, 'utf-8');
console.log('Generated: ' + outPath + ' (' + pages.slides.length + ' slides)');

function buildHtml(opts) {
  const c = opts.tokens.colorSchemes[opts.colorScheme];
  const t = opts.tokens.typography;

  return '<!DOCTYPE html>\n' +
'<html lang="zh-CN">\n' +
'<head>\n' +
'<meta charset="UTF-8">\n' +
'<meta name="viewport" content="width=device-width, initial-scale=1.0">\n' +
'<title>263 PPT - ' + opts.colorScheme + '</title>\n' +
'<style>\n' +
'* { margin:0; padding:0; box-sizing:border-box; }\n' +
'html, body { width:100%; height:100%; overflow:hidden; background:#111; }\n' +
'body { display:flex; justify-content:center; align-items:center; }\n' +
'#player { width:1920px; height:1080px; position:relative; overflow:hidden; transform-origin:center center; }\n' +
'.slide-page { position:absolute !important; top:0; left:0; width:100%; height:100%; opacity:0; transition:opacity 0.35s ease; z-index:0; pointer-events:none; }\n' +
'.slide-page.active { opacity:1; z-index:2; pointer-events:auto; }\n' +
':root {\n' +
'  --primary: ' + c.primary + ';\n' +
'  --primary-light: ' + c.primaryLight + ';\n' +
'  --primary-dark: ' + c.primaryDark + ';\n' +
'  --accent: ' + c.accent + ';\n' +
'  --dark: ' + c.dark + ';\n' +
'  --gray: ' + c.gray + ';\n' +
'  --light-gray: ' + c.lightGray + ';\n' +
'  --white: ' + c.white + ';\n' +
'  --black: ' + c.black + ';\n' +
'}\n' +
'.logo-color-img { background: url(' + opts.logoColorB64 + ') no-repeat center/contain; }\n' +
'.logo-white-img { background: url(' + opts.logoWhiteB64 + ') no-repeat center/contain; }\n' +
'.slogan-img { background: url(' + opts.sloganB64 + ') no-repeat center/contain; }\n' +
'</style>\n' +
'</head>\n' +
'<body>\n' +
'<div id="player">\n' +
opts.slides + '\n' +
'</div>\n' +
'<script>\n' +
'(function() {\n' +
'  var slides = document.querySelectorAll(".slide-page");\n' +
'  var current = 0;\n' +
'  slides[0].classList.add("active");\n' +
'  function show(idx) {\n' +
'    slides[current].classList.remove("active");\n' +
'    current = ((idx % slides.length) + slides.length) % slides.length;\n' +
'    slides[current].classList.add("active");\n' +
'  }\n' +
'  document.getElementById("player").addEventListener("click", function(e) {\n' +
'    var rect = e.currentTarget.getBoundingClientRect();\n' +
'    if (e.clientX < rect.left + rect.width / 2) { show(current - 1); }\n' +
'    else { show(current + 1); }\n' +
'  });\n' +
'  document.addEventListener("keydown", function(e) {\n' +
'    var key = e.key || e.code;\n' +
'    if (key === "ArrowRight" || key === "ArrowDown" || key === "PageDown" || key === " " || key === "Space") {\n' +
'      e.preventDefault(); show(current + 1);\n' +
'    } else if (key === "ArrowLeft" || key === "ArrowUp" || key === "PageUp") {\n' +
'      e.preventDefault(); show(current - 1);\n' +
'    } else if (key === "Home") { e.preventDefault(); show(0); }\n' +
'    else if (key === "End") { e.preventDefault(); show(slides.length - 1); }\n' +
'    else if (key === "f" || key === "F") {\n' +
'      if (document.fullscreenElement) { document.exitFullscreen(); }\n' +
'      else { document.documentElement.requestFullscreen(); }\n' +
'    }\n' +
'  });\n' +
getAsciiAnimationJS() + '\n' +
'  function resize() {\n' +
'    var scale = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);\n' +
'    document.getElementById("player").style.transform = "scale(" + scale + ")";\n' +
'  }\n' +
'  window.addEventListener("resize", resize);\n' +
'  resize();\n' +
'})();\n' +
'</script>\n' +
'</body>\n' +
'</html>';
}

function getAsciiAnimationJS() {
  return [
'  // ASCII entrance animation (auto-detects Template cover, no-op otherwise)',
'  var asciiLines = document.querySelectorAll(".ascii-line");',
'  if (asciiLines.length) {',
'    for (var i = 0; i < asciiLines.length; i++) {',
'      setTimeout(function(idx) {',
'        return function() {',
'          asciiLines[idx].style.opacity = "1";',
'          asciiLines[idx].style.transform = "translateX(0)";',
'        };',
'      }(i), i * 30);',
'    }',
'    var coverContent = document.querySelector(".cover-content");',
'    if (coverContent) {',
'      setTimeout(function() {',
'        coverContent.style.opacity = "1";',
'      }, asciiLines.length * 30 + 200);',
'    }',
'  }',
  ].join('\n');
}
